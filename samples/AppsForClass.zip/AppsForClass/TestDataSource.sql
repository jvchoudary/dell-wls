drop table MYEMP;
create table MYEMP (empid number(4) primary key,name varchar2(20),salary number(7,2));

insert into MYEMP (empid,name,salary) values (1,'Ankur',20000);
insert into MYEMP (empid,name,salary) values (2,'Ranbir',20000);
insert into MYEMP (empid,name,salary) values (3,'Rahul',20000);
insert into MYEMP (empid,name,salary) values (4,'Ramu',20000);
insert into MYEMP (empid,name,salary) values (5,'Baker',20000);
insert into MYEMP (empid,name,salary) values (6,'Bajrang',20000);
insert into MYEMP (empid,name,salary) values (7,'Hamid',20000);
insert into MYEMP (empid,name,salary) values (8,'Hanuman',20000);
insert into MYEMP (empid,name,salary) values (9,'Tapas',20000);
			